x <- lapply(1:1e3, function(x) median(rnorm(1e5)))

library(parallel)
detectCores()
x.mc2 <- mclapply(1:1e3, function(x) median(rnorm(1e5)), mc.cores = 2)
x.mc4 <- mclapply(1:1e3, function(x) median(rnorm(1e5)), mc.cores = 4)

