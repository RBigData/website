library(parallel, quietly = TRUE)
X <- as.matrix(iris[, 1:4])
k <- 3
RNGkind("L'Ecuyer-CMRG")  # mc
set.seed(seed = 123)
FUN <- function(n) {
  isample <- sample(nrow(X), nrow(X), replace = TRUE)
  kmeans(X[isample, ], k, iter.max = 100, nstart = 100)$centers
}

means <- do.call(rbind, mclapply(1:5000, FUN, mc.cores = 2))

pdf("means-k3.pdf")
  plot(X[, c(1, 2)], type = "n")
  points(means[, c(1, 2)], col = rgb(0, 0, 1, 0.2))
  points(X[, c(1, 2)], col = iris[, 5])
dev.off()
