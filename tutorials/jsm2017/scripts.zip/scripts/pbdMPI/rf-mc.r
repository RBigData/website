library(randomForest)
library(mlbench)
data(LetterRecognition)
library(parallel)
RNGkind("L'Ecuyer-CMRG")
set.seed(seed = 123)

n <- nrow(LetterRecognition)
n_test <- floor(0.2 * n)
i_test <- sample.int(n, n_test)
train <- LetterRecognition[-i_test, ]
test <- LetterRecognition[i_test, ]

nc <- detectCores()
ntree <- lapply(splitIndices(500, nc), length)
rf <- function(x) randomForest(lettr ~ ., train, ntree = x, norm.votes = FALSE)
rf.out <- mclapply(ntree, rf, mc.cores = nc)
rf.all <- do.call(combine, rf.out)

crows <- splitIndices(nrow(test), nc)
rfp <- function(x) as.vector(predict(rf.all, test[x, ]))
cpred <- mclapply(crows, rfp, mc.cores = nc)
pred <- do.call(c, cpred)
cat("Proportion Correct:", sum(pred == test$lettr)/(n_test), "\n")
