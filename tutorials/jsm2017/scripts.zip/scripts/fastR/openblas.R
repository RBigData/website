x <- matrix( rnorm( 1e6*1e2 ), nrow = 1e6 )

library(memuse)
howbig(1e6, 1e2, unit="GB")
sessionInfo()

library( openblasctl )

openblas_set_num_threads( 1 )
system.time( y <- t( x ) %*% x )
openblas_set_num_threads( 2 )
system.time( y <- t( x ) %*% x )
openblas_set_num_threads( 4 )
system.time( y <- t( x ) %*% x )

openblas_set_num_threads( 1 )
system.time( z <- crossprod( x ) )
openblas_set_num_threads( 2 )
system.time( z <- crossprod( x ) )
openblas_set_num_threads( 4 )
system.time( z <- crossprod( x ) )
