x <- matrix(rnorm(20000*750), nrow=20000, ncol=750)

system.time(t(x) %*% x)

system.time(crossprod(x))

system.time(a <- cov(x))

system.time(b <- crossprod(scale(x, scale=FALSE))/(nrow(x) - 1))

all.equal(a, b)
