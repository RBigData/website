### Remote procedure calls
library(pbdRPC)
getwd()
ip <- "192.168.56.102"    # need to check vb2 IP
uid <- "snoweye"          # need to check account
exec <- "plink"           # need to check putty
# exec <- "ssh"            # use ssh as default for non-windows system

### Initial an object of virtual machine
myvm <- machine(hostname = ip, user = uid, exec.type = exec)

### Test a shell command on the vm
.pbd_env$RPC.CT
rpc(myvm, cmd = "whoami")
rpc(myvm, cmd = "hostname")
rpc(myvm, cmd = "ifconfig")

### See some examples
.pbd_env$RPC.RR
rpc(myvm, cmd = "cat ~/work-my/00_set_devel_R")

### Set password if needed.
 .pbd_env$RPC.RR$start <-
   paste("nohup",
         "Rscript -e 'remoter::server(password=\\\"pbd\\\")'",
         "> .rrlog 2>&1 < /dev/null &",
         sep = " ")

### Skip password.
# .pbd_env$RPC.RR$start <-
#   paste("nohup",
#         "Rscript -e 'remoter::server()'",
#         "> .rrlog 2>&1 < /dev/null &",
#         sep = " ")

### xvfb-run is a virtual X11 client to allow plotting in batch mode.
.pbd_env$RPC.RR$startx <-
  paste("nohup",
        "xvfb-run Rscript -e 'remoter::server()'",
        "> .rrlog 2>&1 < /dev/null &",
        sep = " ")

### Start remoter server from local.
# start_rr(myvm)   # no virtual X11 client when no need for plotting
# check_rr(myvm)
startx_rr(myvm)    # with virtual X11 client for remote plotting
checkx_rr(myvm)

### Start remoter client from local.
library(remoter)
client(addr = ip)

### Under remoter prompt.
# a <- 1+1
# a
#
# s2c(a)               # Copy `a` to client/laptop.
# q()                  # Check if `a` is right at laptop.
#                      # How about c2s()? Try it.
#
# client(addr = ip)    # Connect back to server again.
#
# rhelp("rpng")
#
# rpng()
# plot(iris$Sepal.Length, iris$Petal.Length)
# rpng.off()
#
# library(ggplot2)
# g1 <- ggplot(iris, aes(x = Sepal.Length, y = Petal.Length,
#              color = Species)) +
#       geom_point(aes(shape = Species))
# rpng()
# print(g1)
# rpng.off()
#
# g1 + geom_smooth(method = "lm")
#
# rpng.new(g1)
#
# b <- function() plot(iris$Sepal.Length, iris$Petal.Length)
# rpng.new(b)
#
# q()
# shutdown()

### Stop remoter server on the vm.
# kill_rr(myvm)   # no virtual X11 client
killx_rr(myvm)   # with virtual X11 client because of remote plotting

