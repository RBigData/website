### Remote procedure calls
library(pbdRPC)
getwd()
ip <- "192.168.56.102"    # need to check vb2 IP
uid <- "snoweye"          # need to check account
exec <- "plink"           # need to check putty
# exec <- "ssh"            # use ssh as default for non-windows system

### Initial an object of virtual machine
myvm <- machine(hostname = ip, user = uid, exec.type = exec)
mpiexec <- "/home/snoweye/work-my/local/ompi/bin/mpiexec"
Rscript <- "/home/snoweye/work-my/local/R-devel/bin/Rscript"

### Test a shell command on the vm
rpc(myvm, cmd = "hostname")
rpc(myvm, cmd = paste(mpiexec, "-np 4 hostname", sep = " "))
rpc(myvm, cmd = paste(mpiexec, "-np 4 -host vb2,vb1 hostname", sep = " "))

### See some examples
.pbd_env$RPC.CS

### Set password if needed.
# .pbd_env$RPC.CS$start <-
#   paste("nohup",
#         mpiexec, "-np 4",
#         Rscript, "-e 'pbdCS::pbdserver(password=\\\"pbd\\\")'",
#         "> .cslog 2>&1 < /dev/null &",
#         sep = " ")

### Skip password.
# .pbd_env$RPC.CS$start <-
#   paste("nohup",
#         mpiexec, "-np 4",
#         Rscript, "-e 'pbdCS::pbdserver()'",
#         "> .cslog 2>&1 < /dev/null &")
#         sep = " ")

### Run mpi and pbdCS server on two nodes.
### 192.168.56.101 vb1
### 192.168.56.102 vb2
### This would work theoretically when everything is right.
.pbd_env$RPC.CS$start <-
  paste("nohup",
        mpiexec, "-np 4 -host vb2,vb1",
        Rscript, "-e 'pbdCS::pbdserver()'",
        "> .cslog 2>&1 < /dev/null &",
        sep = " ")

### Note: Shutdown no needed network interface and firewall from shell on
###       each node except allowing the one for communication among all nodes.
###       e.g. enp0s8 is the only one allowed in my both vm (vb1 and vb2).
### sudo ifconfig enp0s3 down       # This is an NAT to Internet.
### sudo ifconfig docker0 down      # This is for docker.
### sudo ufw disable                # This is firewall.

### Start pbdCS server from local.
start_cs(myvm)
check_cs(myvm)

### Start pbdCS client from local.
library(pbdCS)
pbdclient(addr = ip)

### Under pbdCS prompt.
# library(pbdMPI)
# comm.size()
#
# a <- 1+1
# allreduce(a)
#
# b <- Sys.info()['nodename']
# allgather(b)
# allgather(c(b, comm.rank()))
#
# q()
# shutdown()

### Stop pbdCS server on the vm
kill_cs(myvm)

