library(pbdPROF)

prof <- read.prof("output.mpiP")

plot(prof, plot.type="messages2")
