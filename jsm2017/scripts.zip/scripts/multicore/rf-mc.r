library(randomForest)
library(mlbench)
data(LetterRecognition)
library(parallel)
RNGkind("L'Ecuyer-CMRG")  # mc
set.seed(seed = 123)

n <- nrow(LetterRecognition)
n_test <- floor(0.2 * n)
i_test <- sample.int(n, n_test)
train <- LetterRecognition[-i_test, ]
test <- LetterRecognition[i_test, ]

nc <- detectCores()  # mc
ntree <- lapply(splitIndices(500, nc), length)  # mc
rf <- function(x) randomForest(lettr~., train, ntree=x, norm.votes=FALSE)# mc
rf.out <- mclapply(ntree, rf, mc.cores = nc)  # mc
rf.all <- do.call(combine, rf.out)  # mc

crows <- splitIndices(nrow(test), nc)  # mc
rfp <- function(x) as.vector(predict(rf.all, test[x, ]))  # mc
cpred <- mclapply(crows, rfp, mc.cores = nc)  # mc
pred <- do.call(c, cpred)  # mc
cat("Proportion Correct:", sum(pred == test$lettr)/n_test, "\n")
